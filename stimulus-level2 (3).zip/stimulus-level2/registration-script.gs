function doGet() {
  return ContentService.createTextOutput('Stimulus registration endpoint is live');
}

function doPost(e) {
  const out = (o) => ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
  try {
    const d = JSON.parse(e.postData.contents);
    // If your script is NOT attached to the sheet, replace PASTE_SHEET_ID_HERE with the id from the sheet's URL.
    const ss = SpreadsheetApp.getActiveSpreadsheet() || SpreadsheetApp.openById('PASTE_SHEET_ID_HERE');
    const sh = ss.getSheetByName('Registrations') || ss.insertSheet('Registrations');
    if (sh.getLastRow() === 0) sh.appendRow(['Time', 'Team', 'Project', 'Members', 'Phone', 'Email', 'ID']);
    const ids = sh.getLastRow() > 1 ? sh.getRange(2, 7, sh.getLastRow() - 1, 1).getValues().flat() : [];
    if (ids.indexOf(d.id) < 0) sh.appendRow([new Date(), d.team, d.project, d.members.join(', '), d.phone, d.email, d.id]);
    return out({ ok: true });
  } catch (err) {
    return out({ ok: false, error: String(err) });
  }
}
