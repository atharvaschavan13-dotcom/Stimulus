# Stimulus Level-2 — event site
React + Vite + Three.js (procedural 3D drone, bloom) + GSAP ScrollTrigger + Lenis smooth scroll.

```bash
npm install
npm run dev       # http://localhost:5173
npm run build     # production build in /dist (deploy to Vercel / Netlify / GitHub Pages)
```

- Event details and competitions: `src/data/event.js`
- Drone model and lighting: `src/three/Scene.js`
- Intro + scroll flight path: `src/three/choreo.js`

## Registrations (pick one, set it in `src/data/event.js`)
**A) Google Sheet (recommended):** new Google Sheet → Extensions → Apps Script → paste:
```js
function doPost(e){const d=JSON.parse(e.postData.contents);
SpreadsheetApp.getActiveSheet().appendRow([new Date(),d.team,d.project,d.members.join(', '),d.phone,d.email]);
return ContentService.createTextOutput('ok');}
```
Deploy → New deployment → Web app → Execute as *Me*, access *Anyone* → copy the URL into `registerEndpoint`.
**B) WhatsApp:** put the organiser number (with country code, no +) in `whatsapp`.
**C) Neither:** the form shows the details so teams can copy and send them.

Add photos: drop files in `public/images/` and list them in `EVENT.gallery`.

## Info board (posts, photos, videos)
**Method 1 (code):** edit `src/data/posts.js` — copy a block, change title/text/media/date. Photos go in `public/images/`, local videos in `public/videos/`. YouTube links work directly.
**Method 2 (no code, updates the live site within a minute):** make a NEW Google Sheet (not the registrations one!) with headings in row 1:
`id | date | title | text | media | tag | pinned` (id optional; date like `2026-10-15 09:30`; pinned = yes/no).
File → Share → Publish to web → choose that sheet + **Comma-separated values (.csv)** → Publish → copy the link into `postsSheet` in `src/data/event.js`, then redeploy once. After that, new rows appear on the site automatically.
**Never publish the registrations sheet** — it contains phone numbers and emails.

## Registration script v2 (recommended, replaces the old one)
In the sheet: Extensions → Apps Script → replace ALL code with the script in `registration-script.gs` (included in this zip), Save, then
Deploy → **Manage deployments** → pencil icon → Version: **New version** → Deploy. (The /exec URL stays the same.)
Open the /exec link in a browser: it should say "Stimulus registration endpoint is live".
