import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import { state, track } from './bus.js';
gsap.registerPlugin(ScrollTrigger);

const setDrx = (v) => document.documentElement.style.setProperty('--drx', v);

// Cinematic intro: fly in -> searchlight sweep reveals the title -> settle in the hero.
export function playIntro(onDone) {
  track.on = true;
  const tl = gsap.timeline({ onComplete: () => { track.on = false; onDone && onDone(); } });
  tl.to(state, { z: 0, x: -0.85, y: 0.3, ry: 0.45, s: 1, ring: 1, rotor: 1.5, duration: 2.4, ease: 'power3.out' })
    .to(state, { beam: 1, duration: 0.7 }, 1.5)
    .to(state, { x: 0.9, y: 0.25, ry: -0.5, rz: -0.12, duration: 2.3, ease: 'power2.inOut' }, 2.4)
    .call(() => { track.on = false; setDrx(1.2); }, null, 4.75)
    .to(state, { x: 0.5, y: -0.05, ry: -0.4, rz: 0, s: 1.1, beam: 0, duration: 1.3, ease: 'power3.inOut' }, 4.8)
    .to(state, { minis: 1, duration: 1.6, ease: 'power2.out' }, 5.2);
  return tl;
}

let lenis;
export const lockScroll = (v) => lenis && (v ? lenis.stop() : lenis.start());
export function scramble(el) {
  const final = el.dataset.t || (el.dataset.t = el.textContent), ch = 'ABCDEF0123456789#<>/';
  let f = 0; const iv = setInterval(() => { f++; el.textContent = final.split('').map((c, i) => (c === ' ' || i < f / 2 ? c : ch[(Math.random() * ch.length) | 0])).join(''); if (f / 2 >= final.length) { el.textContent = final; clearInterval(iv); } }, 30);
}
export const goTo = (sel) => lenis && lenis.scrollTo(sel, { offset: -60, duration: 1.6 });

const POSES = {
  hero:    { x: 0.5,   y: -0.05, ry: -0.4, rz: 0,     rx: 0,    s: 1.1,  beam: 0 },
  about:   { x: -0.6,  y: 0,     ry: 0.7,  rz: 0.08,  rx: 0.05, s: 0.85, beam: 0 },
  zonals:  { x: 0.78,  y: 0.25,  ry: -0.9, rz: 0,     rx: 0.25, s: 0.6,  beam: 0 },
  when:    { x: -0.65, y: 0,     ry: 1.1,  rz: -0.08, rx: 0,    s: 0.85, beam: 0.6 },
  prizes:  { x: -0.75, y: 0.05,  ry: 0.8,  rz: 0.05,  rx: 0.08, s: 0.7,  beam: 0.2 },
  updates: { x: -0.7,  y: 0.1,   ry: 0.9,  rz: 0.05,  rx: 0.1,  s: 0.7,  beam: 0.3 },
  fun:     { x: 0.72,  y: -0.1,  ry: -0.8, rz: -0.05, rx: 0,    s: 0.7,  beam: 0 },
  contact: { x: 0,     y: 0.25,  ry: 0,    rz: 0,     rx: 0.1,  s: 0.9,  beam: 1 },
};

// Smooth scroll + scroll-driven drone poses + reveal animations.
export function initScroll() {
  lenis = new Lenis({ lerp: 0.09 });
  lenis.on('scroll', ScrollTrigger.update);
  gsap.ticker.add((t) => lenis.raf(t * 1000));
  gsap.ticker.lagSmoothing(0);

  Object.entries(POSES).forEach(([id, pose]) => {
    ScrollTrigger.create({
      trigger: '#' + id, start: 'top 55%', end: 'bottom 55%',
      onToggle: (self) => {
        if (!self.isActive) return;
        gsap.to(state, { ...pose, duration: 1.8, ease: 'power3.inOut', overwrite: 'auto' });
        if (id === 'zonals') gsap.fromTo(state, { roll: 0 }, { roll: Math.PI * 2, duration: 1.4, ease: 'power2.inOut' }); // barrel roll
      },
    });
  });
  ScrollTrigger.create({ onUpdate: (self) => { state.rotor = Math.min(4, 1 + Math.abs(self.getVelocity()) / 600); state.glitch = Math.min(0.008, Math.abs(self.getVelocity()) / 150000); } });
  gsap.utils.toArray('.rv').forEach((el) =>
    gsap.fromTo(el, { y: 60, opacity: 0 }, { y: 0, opacity: 1, duration: 1, ease: 'power3.out', scrollTrigger: { trigger: el, start: 'top 90%' } })
  );
  gsap.utils.toArray('.scr').forEach((el) => ScrollTrigger.create({ trigger: el, start: 'top 92%', once: true, onEnter: () => scramble(el) }));
  ScrollTrigger.refresh();
}
