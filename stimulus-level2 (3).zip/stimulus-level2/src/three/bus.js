// Shared drone state: GSAP tweens it, the Three.js loop reads it.
// x / y are fractions of the visible half-width / half-height (-1..1).
export const state = { x: -1.4, y: 0.4, z: -40, rx: 0, ry: 0.7, rz: 0, roll: 0, s: 1.2, beam: 0, rotor: 2, ring: 0, minis: 0, glitch: 0 };
export const mouse = { x: 0, y: 0 };
export const track = { on: false };
if (typeof window !== 'undefined') {
  window.addEventListener('pointermove', (e) => {
    mouse.x = e.clientX / innerWidth - 0.5;
    mouse.y = e.clientY / innerHeight - 0.5;
  });
}
