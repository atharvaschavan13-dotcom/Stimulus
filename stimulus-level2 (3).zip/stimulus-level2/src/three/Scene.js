import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { RGBShiftShader } from 'three/examples/jsm/shaders/RGBShiftShader.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { state, mouse, track } from './bus.js';

// A fully procedural chrome quadcopter + neon rings + starfield, with bloom.
export function createScene(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x04050a);
  scene.fog = new THREE.FogExp2(0x04050a, 0.018);
  const cam = new THREE.PerspectiveCamera(40, 1, 0.1, 300);
  cam.position.z = 16;

  const pm = new THREE.PMREMGenerator(renderer);
  scene.environment = pm.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.add(new THREE.AmbientLight(0x223355, 0.6));
  const l1 = new THREE.PointLight(0x00e5ff, 260, 40); l1.position.set(-7, 4, 7);
  const l2 = new THREE.PointLight(0xb04cff, 260, 40); l2.position.set(7, -3, 6);
  const l3 = new THREE.PointLight(0xff3d9a, 120, 30); l3.position.set(0, 6, -4);
  scene.add(l1, l2, l3);

  const M = (c, m, r) => new THREE.MeshStandardMaterial({ color: c, metalness: m, roughness: r });
  const steel = M(0xb9c4dc, 1, 0.2), dark = M(0x0d101b, 0.9, 0.35);
  const glow = (c) => new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(2.2), toneMapped: false });

  const pivot = new THREE.Group(), drone = new THREE.Group();
  pivot.add(drone); scene.add(pivot);

  // body
  const hull = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 24), steel); hull.scale.set(1.25, 0.55, 0.95); drone.add(hull);
  const belly = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 16, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), dark);
  belly.scale.set(1.2, 0.5, 0.9); belly.position.y = -0.05; drone.add(belly);
  const stripe = new THREE.Mesh(new THREE.TorusGeometry(1, 0.025, 8, 64), glow(0x00e5ff));
  stripe.rotation.x = Math.PI / 2; stripe.scale.set(1.26, 0.96, 1); stripe.position.y = 0.02; drone.add(stripe);

  // camera gimbal
  const gim = new THREE.Group(); gim.position.set(0, -0.38, 0.85); drone.add(gim);
  gim.add(new THREE.Mesh(new THREE.SphereGeometry(0.4, 32, 16), dark));
  const lens = new THREE.Mesh(new THREE.SphereGeometry(0.2, 24, 12), glow(0x00e5ff)); lens.position.z = 0.3; gim.add(lens);
  const lr = new THREE.Mesh(new THREE.TorusGeometry(0.27, 0.035, 12, 40), glow(0xb04cff)); lr.position.z = 0.27; gim.add(lr);

  // arms + spinning rotors
  const rotors = [];
  for (let i = 0; i < 4; i++) {
    const a = Math.PI / 4 + (i * Math.PI) / 2, g = new THREE.Group();
    g.rotation.y = -a; drone.add(g);
    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 2.3, 12), dark);
    arm.rotation.z = Math.PI / 2; arm.position.x = 1.3; g.add(arm);
    const motor = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.28, 0.3, 24), steel); motor.position.set(2.45, 0.05, 0); g.add(motor);
    const r = new THREE.Group(); r.position.set(2.45, 0.28, 0); g.add(r);
    const blades = new THREE.Group(); blades.userData.spin = i % 2 ? 1 : -1; r.add(blades);
    for (let b = 0; b < 2; b++) {
      const bl = new THREE.Mesh(new THREE.BoxGeometry(2.3, 0.02, 0.16), M(0xdfe8ff, 0.6, 0.3));
      bl.rotation.y = (b * Math.PI) / 2; blades.add(bl);
    }
    const disc = new THREE.Mesh(new THREE.CircleGeometry(1.2, 48), new THREE.MeshBasicMaterial({
      color: i < 2 ? 0x00e5ff : 0xb04cff, transparent: true, opacity: 0.14, side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false }));
    disc.rotation.x = -Math.PI / 2; r.add(disc);
    const led = new THREE.Mesh(new THREE.SphereGeometry(0.07, 12, 8), glow(i < 2 ? 0x00e5ff : 0xff3d9a)); led.position.set(2.45, -0.15, 0); g.add(led);
    rotors.push({ blades, dir: i % 2 ? 1 : -1 });
  }

  // landing skids
  for (const s of [-1, 1]) {
    const sk = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 2.2, 4, 10), dark);
    sk.rotation.x = Math.PI / 2; sk.position.set(s * 0.8, -1.05, 0); drone.add(sk);
    for (const z of [-0.6, 0.6]) {
      const p = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.7, 8), dark);
      p.position.set(s * 0.8, -0.7, z); p.rotation.z = s * 0.12; drone.add(p);
    }
  }

  // searchlight beam (additive cone, brightest at the apex)
  const beamMat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, uniforms: { u: { value: 0 } },
    vertexShader: 'varying float h;void main(){h=position.y;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
    fragmentShader: 'uniform float u;varying float h;void main(){float a=smoothstep(-14.,0.,h)*.5*u;gl_FragColor=vec4(0.,.9,1.,a*.7);}',
  });
  const coneG = new THREE.ConeGeometry(3.2, 14, 64, 1, true); coneG.translate(0, -7, 0);
  const beam = new THREE.Mesh(coneG, beamMat); beam.position.set(0, -0.5, 0.2); beam.userData.beam = true; drone.add(beam);

  // neon rings (like the poster)
  const mkRing = (r, t) => {
    const g = new THREE.TorusGeometry(r, t, 16, 240), n = g.attributes.position.count, col = new Float32Array(n * 3), c = new THREE.Color();
    for (let i = 0; i < n; i++) {
      const x = g.attributes.position.getX(i), y = g.attributes.position.getY(i), a = (Math.atan2(y, x) / Math.PI + 1) / 2;
      c.setHSL(0.5 + 0.45 * a, 1, 0.55).multiplyScalar(2); col.set([c.r, c.g, c.b], i * 3);
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true, toneMapped: false }));
  };
  const ring1 = mkRing(8, 0.045), ring2 = mkRing(6, 0.025);
  ring1.rotation.set(1.1, 0.3, 0.4); ring2.rotation.set(1.3, -0.4, -0.5);
  const rg = new THREE.Group(); rg.add(ring1, ring2); rg.position.z = -3; scene.add(rg);

  // stars
  const N = 1400, pos = new Float32Array(N * 3);
  for (let i = 0; i < N; i++) { pos[i * 3] = (Math.random() - 0.5) * 90; pos[i * 3 + 1] = (Math.random() - 0.5) * 60; pos[i * 3 + 2] = -Math.random() * 70 + 10; }
  const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const stars = new THREE.Points(sg, new THREE.PointsMaterial({ size: 0.07, color: 0x8fdcff, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false }));
  scene.add(stars);

  // ambient mini-drones that roam the whole site
  const minis = [];
  for (let k = 0; k < 4; k++) {
    const m = drone.clone(true), spinners = [];
    m.traverse((o) => { if (o.userData.beam) o.visible = false; if (o.userData.spin) spinners.push(o); });
    const g = new THREE.Group(); g.add(m); g.userData.px = 0; scene.add(g); minis.push({ g, spinners, k });
  }

  // post-processing
  const comp = new EffectComposer(renderer);
  comp.addPass(new RenderPass(scene, cam));
  comp.addPass(new UnrealBloomPass(new THREE.Vector2(1, 1), 0.85, 0.7, 0.82));
  const rgb = new ShaderPass(RGBShiftShader); comp.addPass(rgb);
  comp.addPass(new OutputPass());

  let halfW = 1, halfH = 1, aspS = 1;
  function resize() {
    const w = innerWidth, h = innerHeight;
    renderer.setSize(w, h, false); comp.setSize(w, h);
    cam.aspect = w / h; cam.updateProjectionMatrix();
    halfH = Math.tan(THREE.MathUtils.degToRad(20)) * cam.position.z; halfW = halfH * cam.aspect;
    aspS = THREE.MathUtils.clamp(cam.aspect / 1.7, 0.5, 1.15);
  }
  resize(); addEventListener('resize', resize);

  const v = new THREE.Vector3(), clamp = THREE.MathUtils.clamp;
  let px = 0, py = 0, last = performance.now(), t = 0, raf;
  function loop(now) {
    raf = requestAnimationFrame(loop);
    const dt = Math.min((now - last) / 1000, 0.05); last = now; t += dt;
    state.rotor += (1 - state.rotor) * Math.min(1, dt * 2);
    rotors.forEach((r) => (r.blades.rotation.y += r.dir * dt * 30 * state.rotor));

    const X = state.x * halfW, Y = state.y * halfH + Math.sin(t * 1.6) * 0.14;
    const vx = (X - px) / Math.max(dt, 0.001), vy = (Y - py) / Math.max(dt, 0.001); px = X; py = Y;
    pivot.position.set(X, Y, state.z);
    pivot.rotation.set(
      state.rx + mouse.y * 0.2 + clamp(-vy * 0.03, -0.4, 0.4) + 0.18,
      state.ry + mouse.x * 0.3,
      state.rz + state.roll - mouse.x * 0.1 + clamp(-vx * 0.035, -0.6, 0.6)
    );
    pivot.scale.setScalar(Math.max(0.001, state.s * aspS));
    beamMat.uniforms.u.value = state.beam;
    state.glitch *= 0.92; rgb.uniforms.amount.value = 0.0008 + state.glitch;
    minis.forEach(({ g, spinners, k }) => {
      const a = t * (0.2 + k * 0.045) + k * 1.9, nx = Math.sin(a) * (0.85 - k * 0.05) * halfW, ny = Math.sin(a * 1.3 + k) * 0.7 * halfH, mvx = (nx - g.userData.px) / Math.max(dt, 0.001);
      g.userData.px = nx; g.position.set(nx, ny, -3 - k * 1.6);
      g.rotation.set(0.18, Math.cos(a) * 0.7, clamp(-mvx * 0.05, -0.5, 0.5));
      g.scale.setScalar(Math.max(0.001, 0.2 * aspS * state.minis));
      spinners.forEach((o) => (o.rotation.y += o.userData.spin * dt * 35));
    });

    rg.scale.setScalar(0.01 + state.ring * 0.99); rg.rotation.y = mouse.x * 0.15;
    ring1.rotation.z = t * 0.25; ring2.rotation.z = -t * 0.4;
    stars.position.x = -mouse.x * 1.2; stars.position.y = mouse.y * 0.8; stars.rotation.z = t * 0.004;

    if (track.on) { v.copy(pivot.position).project(cam); document.documentElement.style.setProperty('--drx', (v.x * 0.5 + 0.5).toFixed(4)); }
    comp.render();
  }
  raf = requestAnimationFrame(loop);
  return { dispose() { cancelAnimationFrame(raf); removeEventListener('resize', resize); renderer.dispose(); } };
}
