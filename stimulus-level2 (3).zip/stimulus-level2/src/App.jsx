import { useEffect, useRef, useState } from 'react';
import { createScene } from './three/Scene.js';
import { initScroll } from './three/choreo.js';
import Intro from './components/Intro.jsx';
import Hero from './components/Hero.jsx';
import Register from './components/Register.jsx';
import { HUD, Nav } from './components/HUD.jsx';
import Board from './components/Board.jsx';
import { Marquee, Countdown, Fleet, Prizes, Faq, Fun, Gallery, Venue, Footer } from './components/Sections.jsx';

export default function App() {
  const cv = useRef(null);
  const [ready, setReady] = useState(false), [entered, setEntered] = useState(false), [reg, setReg] = useState(false);

  useEffect(() => {
    let sc;
    try { sc = createScene(cv.current); } catch (e) { console.warn('WebGL unavailable', e); document.documentElement.style.setProperty('--drx', 2); }
    setReady(true);
    const rip = (e) => { const r = document.createElement('div'); r.className = 'rip'; r.style.left = e.clientX + 'px'; r.style.top = e.clientY + 'px'; document.body.appendChild(r); setTimeout(() => r.remove(), 800); };
    addEventListener('click', rip);
    const mag = (e) => {
      const b = e.target.closest && e.target.closest('.btn,.navreg');
      document.querySelectorAll('.mag').forEach((x) => { if (x !== b) { x.style.transform = ''; x.classList.remove('mag'); } });
      if (b) { const r = b.getBoundingClientRect(); b.classList.add('mag'); b.style.transform = `translate(${(e.clientX - r.left - r.width / 2) * 0.2}px,${(e.clientY - r.top - r.height / 2) * 0.3}px)`; }
    };
    addEventListener('pointermove', mag);
    return () => { sc && sc.dispose(); removeEventListener('click', rip); removeEventListener('pointermove', mag); };
  }, []);

  const onDone = () => { setEntered(true); document.body.classList.add('ready'); requestAnimationFrame(initScroll); };
  const open = () => setReg(true);

  return (
    <>
      <canvas ref={cv} className="gl" />
      <HUD />
      {ready && <Intro onDone={onDone} />}
      <Nav onRegister={open} />
      <main>
        <Hero entered={entered} onRegister={open} />
        <Marquee /><Countdown /><Fleet onRegister={open} /><Prizes onRegister={open} /><Board /><Fun /><Gallery /><Faq /><Venue />
      </main>
      <Footer onRegister={open} />
      <Register open={reg} onClose={() => setReg(false)} />
    </>
  );
}
