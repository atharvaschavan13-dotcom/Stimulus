import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './styles.css';
// No StrictMode on purpose: the WebGL canvas must be created exactly once.
createRoot(document.getElementById('root')).render(<App />);
