// ======= EDIT YOUR EVENT DETAILS HERE =======
export const EVENT = {
  prefix: 'Acharya',
  name: 'Stimulus',
  level: 'Level 2',
  organiser: 'ACCES',
  partner: 'PHN Technology, Pune',
  tagline: "Don't miss the year's most exciting tech event to push innovation boundaries!",
  dates: '15 & 16 Oct 2026',
  time: '9:30 AM',
  venue: 'G.V. Acharya Institute of Engineering and Technology',
  start: '2026-10-15T09:30:00+05:30',
  fee: 500,            // rupees per team
  teamSize: 4,         // max members per team
  payNote: '',         // optional: e.g. 'Pay via UPI: name@bank — details shared at the desk'
  // Where registrations go (use ONE; see README):
  registerEndpoint: 'https://script.google.com/macros/s/AKfycbweV9C9ucDb9z5ecvO0f89SlQpI-MK8z6A0kQOQnYLG7Zaghb8RgUTVAONc0BlFoHv-Aw/exec',  // Google Apps Script URL
  whatsapp: '',          // organiser number with country code, e.g. '919876543210'
  instagram: [
    { label: '@OVAIETSTIMULUS', url: 'https://instagram.com/ovaietstimulus' },
    { label: '@stimulus.level2', url: 'https://instagram.com/stimulus.level2' },
  ],
  postsSheet: '',        // OPTIONAL: published-CSV link of your *posts* sheet (see README) - add posts without redeploying
  gallery: [ // put photos in /public/images and list them here
    { src: '/images/poster.jpg', cap: 'Official poster' },
  ],
};

// Add real photos: put a file in public/images/events/ and set photo: '/images/events/xr.jpg'
export const FLEET = [
  { id: 'xrvr', art: 'xr', photo: '', tag: 'Immersive', title: 'XR / VR Zone', text: 'Step inside virtual worlds and mixed reality experiences.',
    long: 'Put on a headset and step into immersive worlds. Explore virtual environments, try interactive experiences and see how XR is shaping learning, gaming and design.',
    points: ['Hands-on headset demos', 'Immersive worlds and mixed reality', 'See how XR is used in learning, gaming and design', 'Beginner friendly'] },
  { id: 'drone', art: 'drone', photo: '', tag: 'Hands-on', title: 'Drone Workshop', text: 'Learn how drones fly, then take the controls.',
    long: 'Learn the basics of how drones fly: the parts, the controls, balance and safe flying. Then take the controls yourself.',
    points: ['How drones fly: motors, props and controllers', 'Safety basics before takeoff', 'Fly it yourself under guidance', 'Great for beginners'] },
  { id: 'web', art: 'web', photo: '', tag: 'Build', title: 'Web Development', text: 'Design and ship a live website from scratch.',
    long: 'Go from a blank page to a live website. Learn how a modern site is structured, styled and made interactive, and build your own as you go.',
    points: ['HTML, CSS and JavaScript fundamentals', 'Build a real page step by step', 'Learn how websites go live', 'Take your project home'] },
  { id: 'ai', art: 'ai', photo: '', tag: 'Fun', title: 'AI Snapshot Booth', text: 'Strike a pose and let AI transform your photo.',
    long: 'Step up to the camera and let AI turn your photo into something unexpected. Pick a style, strike a pose and share the result.',
    points: ['Strike a pose, pick a style', 'AI turns your photo into something new', 'Share it with friends', 'Fun for everyone'] },
];
export const FLEET_SLOT = 'Timings will be announced on the Live Board';

export const PRIZES = [
  { place: '1st', amount: 25000, medal: 'gold', label: 'Winner' },
  { place: '2nd', amount: 15000, medal: 'silver', label: 'Runner-up' },
  { place: '3rd', amount: 10000, medal: 'bronze', label: 'Second runner-up' },
];

export const FAQ = [
  ['How much does it cost to register?', `₹${500} per team. The fee is for the whole team, not per person.`],
  ['How many people can be in a team?', 'Up to 4 members per team, including the team leader.'],
  ['What are the prizes?', '1st place wins ₹25,000, 2nd place ₹15,000 and 3rd place ₹10,000.'],
  ['When and where is it?', '15 and 16 October 2026, starting 9:30 AM at G.V. Acharya Institute of Engineering and Technology.'],
  ['How do I register?', 'Tap Register, enter your team name, project name and members, and submit. Updates are posted on the Live Board.'],
];

export const FUN = [
  { art: 'game', title: 'Fun Games', text: 'Play, compete and win on the floor.' },
  { art: 'stage', title: 'Performances', text: 'Live stage acts across both days.' },
  { art: 'more', title: 'And Much More', text: 'Surprises revealed through the daily updates.' },
];

// Daily updates: add a new line at the TOP each day.
export const UPDATES = [
  { day: 'Day 1 · 15 Oct', time: '9:30 AM', text: 'Gates open. Registration desk and check-in begin.' },
  { day: 'Day 2 · 16 Oct', time: '9:30 AM', text: 'Second day kicks off. Workshops, games and performances continue.' },
  { day: 'Every day', time: 'LIVE', text: 'New announcements land here. Keep this page open.' },
];
