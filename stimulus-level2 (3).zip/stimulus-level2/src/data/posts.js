// ===================== INFO BOARD POSTS =====================
// Add a new post by copying one block. Newest date shows first; pinned: true keeps it on top.
//   date   : 'YYYY-MM-DDTHH:MM:SS+05:30'
//   title  : headline
//   text   : the message (optional)
//   media  : (optional) one of:
//            - photo   -> '/images/my-photo.jpg'   (put the file in public/images)
//            - video   -> a YouTube link, or '/videos/clip.mp4' (file in public/videos)
//            - link    -> any other URL (e.g. an Instagram reel/post) shows a card that opens it
//   tag    : small label e.g. 'Announcement', 'Day 1', 'Winners'
//   pinned : true / false
// TIP: to add posts WITHOUT touching code, use the Google Sheet method in README (postsSheet).
export const POSTS = [
  {
    id: 'prizes',
    date: '2026-10-08T12:00:00+05:30',
    title: '₹50,000 prize pool',
    text: '1st place wins ₹25,000, 2nd place ₹15,000 and 3rd place ₹10,000. Register your team now.',
    tag: 'Prizes',
    pinned: true,
  },
  {
    id: 'reg-open',
    date: '2026-10-08T10:00:00+05:30',
    title: 'Team registrations are open',
    text: 'Register your team (up to 4 members) for just ₹500 per team. Tap Register at the top of the page.',
    tag: 'Announcement',
    pinned: true,
  },
  {
    id: 'poster',
    date: '2026-10-05T19:00:00+05:30',
    title: 'Official poster is out',
    text: "Don't miss the year's most exciting tech event to push innovation boundaries. 15 & 16 October 2026.",
    media: '/images/poster.jpg',
    tag: 'Poster',
  },
  {
    id: 'day1',
    date: '2026-10-15T09:30:00+05:30',
    title: 'Day 1: gates open at 9:30 AM',
    text: 'Check-in begins at G.V. Acharya Institute of Engineering and Technology.',
    tag: 'Day 1',
  },
];
