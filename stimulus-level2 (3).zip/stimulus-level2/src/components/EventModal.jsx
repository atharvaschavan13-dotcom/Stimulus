import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import Art from './Art.jsx';
import { FLEET_SLOT } from '../data/event.js';
import { lockScroll } from '../three/choreo.js';

export default function EventModal({ e, onClose, onNav, onRegister }) {
  const box = useRef(null);
  useEffect(() => {
    lockScroll(true);
    const tl = gsap.timeline();
    tl.fromTo(box.current, { scale: 0.85, opacity: 0, y: 60, rotateX: 12, filter: 'blur(12px)' }, { scale: 1, opacity: 1, y: 0, rotateX: 0, filter: 'blur(0px)', duration: 0.7, ease: 'power3.out' })
      .fromTo('.em-li', { x: -30, opacity: 0 }, { x: 0, opacity: 1, stagger: 0.09, duration: 0.5, ease: 'power2.out' }, 0.35)
      .fromTo('.em-stage .art', { scale: 0.6, rotate: -8, opacity: 0 }, { scale: 1, rotate: 0, opacity: 1, duration: 0.9, ease: 'elastic.out(1,.5)' }, 0.2);
    const key = (ev) => { if (ev.key === 'Escape') onClose(); if (ev.key === 'ArrowRight') onNav(1); if (ev.key === 'ArrowLeft') onNav(-1); };
    addEventListener('keydown', key);
    return () => { removeEventListener('keydown', key); lockScroll(false); tl.kill(); };
  }, [e.id]);
  return (
    <div className="lb" onClick={onClose}>
      <button className="lb-x mono" onClick={onClose}>CLOSE ✕</button>
      <button className="lb-n l" onClick={(x) => { x.stopPropagation(); onNav(-1); }}>‹</button>
      <button className="lb-n r" onClick={(x) => { x.stopPropagation(); onNav(1); }}>›</button>
      <div className="lb-box em" ref={box} onClick={(x) => x.stopPropagation()}>
        <div className="em-stage">
          <i className="orb o1" /><i className="orb o2" /><div className="grid3" />
          {e.photo ? <img className="em-photo" src={e.photo} alt={e.title} /> : <Art k={e.art} />}
        </div>
        <div className="em-body">
          <span className="ptag mono">{e.tag}</span>
          <h3 className="d">{e.title}</h3>
          <p>{e.long}</p>
          <ul>{e.points.map((p) => <li className="em-li" key={p}><b>✓</b>{p}</li>)}</ul>
          <div className="slot mono">⏱ {FLEET_SLOT}</div>
          <button className="btn" onClick={() => { onClose(); setTimeout(onRegister, 350); }}>Register your team</button>
        </div>
      </div>
    </div>
  );
}
