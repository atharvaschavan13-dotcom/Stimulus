import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { playIntro } from '../three/choreo.js';
import { EVENT } from '../data/event.js';

const BOOT = ['> DRONE_UNIT_01 ...... ONLINE', '> ROTORS ............ SPINNING', '> CAMERA ............ LOCKED', `> TARGET: ${EVENT.name.toUpperCase()} ${EVENT.level.toUpperCase()}`, '> TAKEOFF SEQUENCE ENGAGED'];

export default function Intro({ onDone }) {
  const root = useRef(null), pct = useRef(null), tlRef = useRef(null);
  const [lines, setLines] = useState([]);

  useEffect(() => {
    const timers = BOOT.map((t, i) => setTimeout(() => setLines((l) => [...l, t]), 250 + i * 380));
    const tl = playIntro(() => {
      gsap.to(root.current, { opacity: 0, duration: 0.9, onComplete: () => { root.current.style.display = 'none'; onDone(); } });
    });
    tl.to('.i-w', { opacity: 1, y: 0, duration: 0.8 }, 0.8)
      .to('.i-l2, .i-dt', { opacity: 1, y: 0, duration: 0.9, stagger: 0.2 }, 5.0);
    tl.eventCallback('onUpdate', () => { if (pct.current) pct.current.textContent = Math.round(tl.progress() * 100) + '%'; });
    tlRef.current = tl;
    return () => { timers.forEach(clearTimeout); tl.kill(); };
  }, []);

  return (
    <div className="intro" ref={root}>
      <img className="i-logo" src="/images/logo.png" alt="Stimulus logo" />
      <div className="hr" /><div className="hr b" /><div className="lad" />
      <div className="boot mono">{lines.map((l) => <div key={l}>{l}</div>)}</div>
      <div className="wt">
        <div className="i-w d">Welcome to {EVENT.prefix}</div>
        <div className="big d">{EVENT.name}</div>
        <div className="i-l2 d">{EVENT.level}</div>
        <div className="i-dt d">{EVENT.dates} · {EVENT.time}</div>
      </div>
      <div className="plabel mono">LOADING <span ref={pct}>0%</span></div>
      <button className="skip mono" onClick={() => tlRef.current && tlRef.current.progress(1)}>SKIP ▸</button>
    </div>
  );
}
