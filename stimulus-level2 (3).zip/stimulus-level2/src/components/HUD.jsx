import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { state } from '../three/bus.js';
import { EVENT } from '../data/event.js';
import { goTo } from '../three/choreo.js';

export function HUD() {
  const tele = useRef(null), prog = useRef(null), halo = useRef(null);
  useEffect(() => {
    const qx = gsap.quickTo(halo.current, 'x', { duration: 0.5, ease: 'power3' }), qy = gsap.quickTo(halo.current, 'y', { duration: 0.5, ease: 'power3' });
    const mv = (e) => { qx(e.clientX); qy(e.clientY); };
    let bat = 100;
    const iv = setInterval(() => {
      bat = Math.max(12, bat - 0.05);
      const max = document.body.scrollHeight - innerHeight || 1;
      prog.current.style.width = (scrollY / max) * 100 + '%';
      tele.current.innerHTML = `ALT ${Math.round(scrollY / 8 + 120)}M<br>ROTOR ${Math.round(state.rotor * 2400)} RPM<br>BAT ${bat.toFixed(0)}%<br>LINK ACHARYA-STIMULUS-L2`;
    }, 120);
    addEventListener('pointermove', mv);
    return () => { clearInterval(iv); removeEventListener('pointermove', mv); };
  }, []);
  return (
    <>
      <div className="prog" ref={prog} />
      <div className="halo" ref={halo} />
      <div className="hud"><i /><i /><i /><i /><div className="tele mono" ref={tele} /><div className="rec mono">REC</div></div>
    </>
  );
}

export function Nav({ onRegister }) {
  const go = (s) => (e) => { e.preventDefault(); goTo(s); };
  return (
    <nav>
      <a className="logo" href="#hero" onClick={go('#hero')}><img src="/images/logo.png" alt="Stimulus" /></a>
      <div>
        <a href="#zonals" onClick={go('#zonals')}>Events</a>
        <a href="#prizes" className="h" onClick={go('#prizes')}>Prizes</a>
        <a href="#updates" className="h" onClick={go('#updates')}>Updates</a>
        <a href="#fun" className="h" onClick={go('#fun')}>Fun Zone</a>
        <a href="#when" className="h" onClick={go('#when')}>Venue</a>
        <button className="navreg" onClick={onRegister}>Register</button>
      </div>
    </nav>
  );
}
