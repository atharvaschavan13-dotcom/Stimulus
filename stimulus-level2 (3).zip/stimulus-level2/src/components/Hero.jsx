import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { EVENT, FLEET, PRIZES } from '../data/event.js';
import { goTo } from '../three/choreo.js';

export default function Hero({ entered, onRegister }) {
  const wd = useRef(null);
  useEffect(() => {
    if (!entered) return;
    const words = [...FLEET.map((f) => f.title), 'Games & Performances', `₹${PRIZES.reduce((a, p) => a + p.amount, 0).toLocaleString('en-IN')} in prizes`];
    let i = 0;
    const swap = () => { gsap.timeline().to(wd.current, { yPercent: -100, opacity: 0, duration: 0.35, ease: 'power2.in' }).add(() => { wd.current.textContent = words[i++ % words.length]; }).fromTo(wd.current, { yPercent: 100, opacity: 0 }, { yPercent: 0, opacity: 1, duration: 0.5, ease: 'power3.out' }); };
    const t0 = setTimeout(swap, 1800), iv = setInterval(swap, 2600);
    return () => { clearTimeout(t0); clearInterval(iv); };
  }, [entered]);
  useEffect(() => {
    if (!entered) return;
    gsap.fromTo('.h1 span', { yPercent: 115, rotateX: -80, opacity: 0 }, { yPercent: 0, rotateX: 0, opacity: 1, stagger: 0.08, duration: 1.2, ease: 'power4.out' });
    gsap.fromTo('.hero-in', { y: 40, opacity: 0 }, { y: 0, opacity: 1, stagger: 0.1, duration: 1, delay: 0.4, ease: 'power3.out' });
  }, [entered]);
  return (
    <header id="hero" className="hero">
      <div className="floor" />
      <div className="radar"><i style={{ left: '62%', top: '30%' }} /><i style={{ left: '30%', top: '64%', animationDelay: '.6s' }} /><i style={{ left: '70%', top: '72%', animationDelay: '1s' }} /></div>
      <div className="side mono">SCROLL TO FLY ▸ {EVENT.prefix.toUpperCase()} {EVENT.name.toUpperCase()} {EVENT.level.toUpperCase()}</div>
      <p className="pre d hero-in">Organised by {EVENT.organiser} · In association with {EVENT.partner}</p>
      <div className="prefix d hero-in">{EVENT.prefix}</div>
      <h1 className="h1 d">{EVENT.name.toUpperCase().split('').map((c, i) => <span key={i}>{c}</span>)}</h1>
      <div className="lvl d hero-in">{EVENT.level}</div>
      <div className="words d hero-in"><span ref={wd}>&nbsp;</span></div>
      <p className="tag hero-in">{EVENT.tagline}</p>
      <div className="meta hero-in"><span className="pill">{EVENT.dates}</span><span className="pill">{EVENT.time}</span><span className="pill">{EVENT.venue}</span></div>
      <div className="cta hero-in">
        <button className="btn" onClick={onRegister}>Register your team · ₹{EVENT.fee}</button>
        <a className="ghost" href="#zonals" onClick={(e) => { e.preventDefault(); goTo('#zonals'); }}>Explore events</a>
      </div>
      <div className="stats d hero-in"><div><b>02</b><small>Days</small></div><div><b>09:30</b><small>Takeoff</small></div><div><b>₹{PRIZES.reduce((a, p) => a + p.amount, 0) / 1000}K</b><small>Prizes</small></div></div>
    </header>
  );
}
