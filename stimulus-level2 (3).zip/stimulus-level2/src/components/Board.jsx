import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { EVENT } from '../data/event.js';
import { POSTS } from '../data/posts.js';
import { DroneIcon } from './Art.jsx';
import { lockScroll } from '../three/choreo.js';
gsap.registerPlugin(ScrollTrigger);

const ytId = (u) => { const m = (u || '').match(/(?:youtu\.be\/|v=|embed\/|shorts\/)([\w-]{11})/); return m && m[1]; };
const kindOf = (m) => !m ? 'text' : ytId(m) ? 'youtube' : /\.(mp4|webm|mov)(\?|$)/i.test(m) ? 'video' : /\.(png|jpe?g|gif|webp|avif|svg)(\?|$)/i.test(m) || m.startsWith('/images') ? 'image' : 'link';
const CAT = { text: 'Announcements', image: 'Photos', youtube: 'Videos', video: 'Videos', link: 'Links' };
const ago = (d) => {
  const s = (Date.now() - new Date(d)) / 1000;
  if (s < 0) return 'Upcoming · ' + new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
  if (s < 3600) return Math.max(1, Math.floor(s / 60)) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  if (s < 604800) return Math.floor(s / 86400) + 'd ago';
  return new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
};
function parseCSV(t) {
  const rows = []; let r = [], c = '', q = false;
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (q) { if (ch === '"' && t[i + 1] === '"') { c += '"'; i++; } else if (ch === '"') q = false; else c += ch; }
    else if (ch === '"') q = true; else if (ch === ',') { r.push(c); c = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && t[i + 1] === '\n') i++; r.push(c); rows.push(r); r = []; c = ''; }
    else c += ch;
  }
  if (c || r.length) { r.push(c); rows.push(r); }
  const [h, ...rest] = rows.filter((x) => x.some((v) => v.trim()));
  const keys = h.map((k) => k.trim().toLowerCase());
  return rest.map((row) => { const o = {}; keys.forEach((k, i) => (o[k] = (row[i] || '').trim())); return { id: o.id || o.title + o.date, date: o.date || new Date().toISOString(), title: o.title, text: o.text, media: o.media, tag: o.tag, pinned: /^(true|yes|1|y)$/i.test(o.pinned) }; }).filter((p) => p.title);
}
const ls = { get: (k) => { try { return localStorage.getItem(k); } catch { return null; } }, set: (k, v) => { try { localStorage.setItem(k, v); } catch {} } };

function status() {
  const n = Date.now(), s = new Date(EVENT.start).getTime(), D = 864e5;
  if (n < s) return ['COUNTING DOWN', `Starts in ${Math.ceil((s - n) / D)} day${Math.ceil((s - n) / D) > 1 ? 's' : ''}`];
  if (n < s + D) return ['LIVE NOW', 'Day 1 is happening'];
  if (n < s + 2 * D) return ['LIVE NOW', 'Day 2 is happening'];
  return ['CONCLUDED', 'Thank you for being part of it'];
}

function Card({ p, onOpen, toast }) {
  const ref = useRef(null), k = kindOf(p.media), id = 'rx:' + p.id;
  const [liked, setLiked] = useState(ls.get(id) === '1');
  const isNew = Date.now() - new Date(p.date) < 864e5 && Date.now() >= new Date(p.date);
  const [more, setMore] = useState(false);
  const tilt = (e) => { const c = ref.current, r = c.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5; c.style.transform = `perspective(900px) rotateY(${x * 9}deg) rotateX(${-y * 9}deg)`; c.style.setProperty('--gx', (x + 0.5) * 100 + '%'); c.style.setProperty('--gy', (y + 0.5) * 100 + '%'); };
  const react = (e) => {
    e.stopPropagation(); const v = !liked; setLiked(v); ls.set(id, v ? '1' : '0');
    if (!v) return;
    const b = e.currentTarget;
    for (let i = 0; i < 9; i++) { const s = document.createElement('span'); s.textContent = ['🔥', '⚡', '✨'][i % 3]; s.className = 'burst'; b.appendChild(s); gsap.fromTo(s, { x: 0, y: 0, opacity: 1, scale: 0.6 }, { x: (Math.random() - 0.5) * 120, y: -40 - Math.random() * 90, opacity: 0, scale: 1.3, duration: 0.9, ease: 'power2.out', onComplete: () => s.remove() }); }
  };
  const share = async (e) => {
    e.stopPropagation(); const url = location.origin + location.pathname + '#' + p.id;
    try { if (navigator.share) await navigator.share({ title: p.title, url }); else { await navigator.clipboard.writeText(url); toast('Link copied'); } } catch {}
  };
  const thumb = k === 'youtube' ? `https://img.youtube.com/vi/${ytId(p.media)}/hqdefault.jpg` : k === 'image' ? p.media : null;
  return (
    <div className="pw">
      <article ref={ref} id={p.id} className={'pcard' + (p.pinned ? ' pin' : '')} onMouseMove={tilt} onMouseLeave={() => (ref.current.style.transform = '')} onClick={() => onOpen(p)}>
        {p.pinned && <span className="pinb mono">📌 PINNED</span>}
        {isNew && <span className="newb mono">NEW</span>}
        {k !== 'text' && (
          <div className="pm">
            {thumb && <img src={thumb} alt={p.title} loading="lazy" />}
            {k === 'video' && <video src={p.media} muted loop playsInline preload="metadata" onMouseEnter={(e) => e.target.play()} onMouseLeave={(e) => e.target.pause()} />}
            {k === 'link' && <div className="lnk d">↗ Open link</div>}
            {(k === 'youtube' || k === 'video') && <span className="play"><i /></span>}
          </div>
        )}
        <div className="pb">
          <div className="pmeta mono">{p.tag && <span className="ptag">{p.tag}</span>}<span>{ago(p.date)}</span></div>
          <h3 className="d">{p.title}</h3>
          {p.text && <p className={more ? 'open' : ''}>{p.text}</p>}
          {p.text && p.text.length > 120 && <button className="more mono" onClick={(e) => { e.stopPropagation(); setMore(!more); }}>{more ? 'SHOW LESS' : 'READ MORE'}</button>}
          <div className="pact"><button className={'rx' + (liked ? ' on' : '')} onClick={react}>🔥 {liked ? 'Fired up' : 'React'}</button><button onClick={share}>↗ Share</button></div>
        </div>
        <i className="shine" />
      </article>
    </div>
  );
}

function Lightbox({ p, list, onClose, onNav }) {
  const box = useRef(null), k = kindOf(p.media);
  useEffect(() => {
    lockScroll(true);
    gsap.fromTo(box.current, { scale: 0.86, opacity: 0, y: 50, filter: 'blur(12px)' }, { scale: 1, opacity: 1, y: 0, filter: 'blur(0px)', duration: 0.6, ease: 'power3.out' });
    const key = (e) => { if (e.key === 'Escape') onClose(); if (e.key === 'ArrowRight') onNav(1); if (e.key === 'ArrowLeft') onNav(-1); };
    addEventListener('keydown', key);
    return () => { removeEventListener('keydown', key); lockScroll(false); };
  }, [p.id]);
  return (
    <div className="lb" onClick={onClose}>
      <button className="lb-x mono" onClick={onClose}>CLOSE ✕</button>
      {list.length > 1 && <><button className="lb-n l" onClick={(e) => { e.stopPropagation(); onNav(-1); }}>‹</button><button className="lb-n r" onClick={(e) => { e.stopPropagation(); onNav(1); }}>›</button></>}
      <div className="lb-box" ref={box} onClick={(e) => e.stopPropagation()}>
        {k === 'youtube' && <div className="vid"><iframe src={`https://www.youtube-nocookie.com/embed/${ytId(p.media)}?autoplay=1&rel=0`} allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen title={p.title} /></div>}
        {k === 'video' && <video className="vid" src={p.media} controls autoPlay playsInline />}
        {k === 'image' && <img src={p.media} alt={p.title} />}
        <div className="lb-t"><div className="pmeta mono">{p.tag && <span className="ptag">{p.tag}</span>}<span>{ago(p.date)}</span></div><h3 className="d">{p.title}</h3>{p.text && <p>{p.text}</p>}
          {k === 'link' && <a className="btn" href={p.media} target="_blank" rel="noreferrer">Open link ↗</a>}</div>
      </div>
    </div>
  );
}

export default function Board() {
  const [remote, setRemote] = useState([]), [filter, setFilter] = useState('All'), [open, setOpen] = useState(null), [msg, setMsg] = useState(''), [, tick] = useState(0);
  const seen = useRef(null), first = useRef(true);
  const toast = useCallback((m) => { setMsg(m); setTimeout(() => setMsg(''), 2600); }, []);

  useEffect(() => { const iv = setInterval(() => tick((x) => x + 1), 60000); return () => clearInterval(iv); }, []);
  useEffect(() => {
    if (!EVENT.postsSheet) return;
    const load = () => fetch(EVENT.postsSheet + (EVENT.postsSheet.includes('?') ? '&' : '?') + 't=' + Date.now()).then((r) => r.text()).then((t) => {
      const ps = parseCSV(t);
      if (seen.current && ps.some((p) => !seen.current.has(p.id))) toast('📡 New post just landed!');
      seen.current = new Set(ps.map((p) => p.id)); setRemote(ps);
    }).catch(() => {});
    load(); const iv = setInterval(load, 60000); return () => clearInterval(iv);
  }, []);

  const all = useMemo(() => {
    const m = new Map(); [...POSTS, ...remote].forEach((p) => m.set(p.id, p));
    return [...m.values()].sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0) || new Date(b.date) - new Date(a.date));
  }, [remote]);
  const cats = ['All', ...new Set(all.map((p) => CAT[kindOf(p.media)]))];
  const list = filter === 'All' ? all : all.filter((p) => CAT[kindOf(p.media)] === filter);
  const [st, stText] = status();

  useEffect(() => {
    gsap.fromTo('.pw', { y: 90, opacity: 0, rotateX: -18, scale: 0.94 }, { y: 0, opacity: 1, rotateX: 0, scale: 1, stagger: 0.09, duration: 0.9, ease: 'power3.out', overwrite: true, scrollTrigger: first.current ? { trigger: '.board', start: 'top 85%' } : undefined });
    first.current = false;
  }, [filter, all.length]);
  useEffect(() => { const h = location.hash.slice(1), p = all.find((x) => x.id === h); if (p) setOpen(p); }, [remote.length]);

  const nav = (d) => { const i = list.findIndex((x) => x.id === open.id); setOpen(list[(i + d + list.length) % list.length]); };

  return (
    <section id="updates">
      <div className="kick mono scr">// 02 / INFO BOARD</div>
      <h2 className="d rv">Live <em>Board</em></h2>
      <div className="bhead rv">
        <span className={'stat mono ' + (st === 'LIVE NOW' ? 'live' : '')}><i />{st}</span><span className="sub2">{stText}</span>
        <div className="courier"><DroneIcon /><div className="env" /></div>
      </div>
      <div className="ticker mono"><div>{[...all, ...all].map((p, i) => <span key={i}>◆ {p.title}</span>)}</div></div>
      <div className="chips rv">{cats.map((c) => <button key={c} className={c === filter ? 'on' : ''} onClick={() => setFilter(c)}>{c}</button>)}</div>
      <div className="board">{list.map((p) => <Card key={p.id} p={p} onOpen={setOpen} toast={toast} />)}</div>
      {open && <Lightbox p={open} list={list} onClose={() => { setOpen(null); history.replaceState(null, '', location.pathname); }} onNav={nav} />}
      <div className={'toast mono' + (msg ? ' on' : '')}>{msg}</div>
    </section>
  );
}
