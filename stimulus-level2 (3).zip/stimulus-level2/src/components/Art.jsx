// Animated SVG illustrations (swap for real photos any time).
export function DroneIcon() {
  return (
    <svg className="di" viewBox="0 0 120 50">
      <path d="M60 28L16 14M60 28L104 14" stroke="#2a3350" strokeWidth="5" strokeLinecap="round" />
      {[16, 104].map((x) => (
        <g key={x} transform={`translate(${x} 12) scale(1 .25)`}><circle r="20" fill="rgba(0,229,255,.2)" /><path className="rot" d="M-20 0H20" stroke="#cfe" strokeWidth="3" /></g>
      ))}
      <rect x="42" y="20" width="36" height="20" rx="9" fill="#9fb0d0" stroke="#e6eeff" />
      <circle cx="60" cy="38" r="5" fill="#00e5ff" /><circle className="led" cx="48" cy="28" r="1.8" fill="#ff3355" />
    </svg>
  );
}

const C = '#00e5ff', P = '#b04cff', K = '#ff3d9a';
export default function Art({ k }) {
  const s = { fill: 'none', stroke: C, strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const art = {
    xr: (<g className="float"><rect x="22" y="30" width="76" height="34" rx="14" fill="#0b1226" stroke={C} strokeWidth="2" /><circle cx="46" cy="47" r="9" fill={C} opacity=".85" className="pulse" /><circle cx="74" cy="47" r="9" fill={P} opacity=".85" className="pulse" /><path d="M22 44H10M98 44h12" {...s} /><g className="orbit"><rect x="54" y="6" width="12" height="12" fill="none" stroke={K} strokeWidth="2" /></g></g>),
    drone: (<g className="float"><path d="M60 45L24 25M60 45L96 25M60 45L24 65M60 45L96 65" {...s} />{[[24, 25], [96, 25], [24, 65], [96, 65]].map(([x, y]) => <g key={x + '' + y} transform={`translate(${x} ${y})`}><circle r="11" fill="rgba(0,229,255,.15)" stroke={P} /><path className="rot" d="M-11 0H11" stroke="#fff" strokeWidth="2" /></g>)}<rect x="46" y="36" width="28" height="18" rx="8" fill="#0b1226" stroke={C} strokeWidth="2" /><circle cx="60" cy="45" r="4" fill={C} className="pulse" /></g>),
    web: (<g className="float"><rect x="14" y="12" width="92" height="64" rx="6" fill="#0b1226" stroke={C} strokeWidth="2" /><path d="M14 26H106" {...s} />{[0, 1, 2].map((i) => <circle key={i} cx={22 + i * 8} cy="19" r="2" fill={[K, P, C][i]} />)}{[[24, 38, 40], [32, 48, 56], [32, 58, 30], [24, 68, 44]].map(([x, y, w], i) => <rect key={i} className="bar" style={{ animationDelay: i * 0.3 + 's' }} x={x} y={y} width={w} height="4" rx="2" fill={[C, P, K, C][i]} />)}</g>),
    ai: (<g className="float"><rect x="20" y="26" width="80" height="48" rx="10" fill="#0b1226" stroke={C} strokeWidth="2" /><circle cx="60" cy="50" r="15" fill="none" stroke={P} strokeWidth="2.5" /><circle cx="60" cy="50" r="7" fill={C} className="pulse" /><path d="M44 26l5-8h22l5 8" {...s} /><path className="scan" d="M26 50H94" stroke={K} strokeWidth="2" /><path className="spark" d="M100 14l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" fill={K} /></g>),
    game: (<g className="float"><path d="M30 34h60a14 14 0 0 1 14 15l-4 18a8 8 0 0 1-14 2l-6-8H40l-6 8a8 8 0 0 1-14-2l-4-18A14 14 0 0 1 30 34z" fill="#0b1226" stroke={C} strokeWidth="2" /><path d="M38 46v12M32 52h12" {...s} /><circle className="pulse" cx="82" cy="46" r="3" fill={K} /><circle className="pulse" style={{ animationDelay: '.4s' }} cx="90" cy="53" r="3" fill={C} /><circle className="pulse" style={{ animationDelay: '.8s' }} cx="74" cy="53" r="3" fill={P} /></g>),
    stage: (<g><path className="beam2" d="M60 6L30 78H90z" fill="rgba(176,76,255,.25)" /><rect x="52" y="28" width="16" height="26" rx="8" fill="#0b1226" stroke={C} strokeWidth="2" className="float" /><path d="M46 46a14 14 0 0 0 28 0M60 60v10M50 70h20" {...s} /></g>),
    more: (<g>{[[30, 30, 1], [88, 24, 0.7], [60, 56, 1.3], [96, 66, 0.6], [24, 68, 0.8]].map(([x, y, sc], i) => <path key={i} className="spark" style={{ animationDelay: i * 0.35 + 's', transformOrigin: `${x}px ${y}px` }} transform={`translate(${x} ${y}) scale(${sc})`} d="M0-10l3 7 7 3-7 3-3 7-3-7-7-3 7-3z" fill={[C, P, K][i % 3]} />)}</g>),
  }[k];
  return <svg className="art" viewBox="0 0 120 90">{art}</svg>;
}
