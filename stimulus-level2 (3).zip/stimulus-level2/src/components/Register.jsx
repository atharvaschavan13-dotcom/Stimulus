import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { EVENT, PRIZES } from '../data/event.js';
import { lockScroll } from '../three/choreo.js';

const blank = { team: '', project: '', members: Array(EVENT.teamSize).fill(''), phone: '', email: '' };

export default function Register({ open, onClose }) {
  const root = useRef(null);
  const [f, setF] = useState(blank), [err, setErr] = useState({}), [done, setDone] = useState(null), [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    lockScroll(true);
    gsap.fromTo(root.current, { clipPath: 'circle(0% at 90% 8%)' }, { clipPath: 'circle(150% at 90% 8%)', duration: 1, ease: 'power3.inOut' });
    gsap.fromTo('.rg-in', { y: 40, opacity: 0 }, { y: 0, opacity: 1, stagger: 0.07, duration: 0.7, delay: 0.5, ease: 'power3.out' });
    const esc = (e) => e.key === 'Escape' && close();
    addEventListener('keydown', esc);
    return () => removeEventListener('keydown', esc);
  }, [open]);

  useEffect(() => {
    if (!done) return;
    const cols = ['#00e5ff', '#b04cff', '#ff3d9a', '#ffffff'];
    for (let i = 0; i < 70; i++) {
      const c = document.createElement('i');
      c.style.cssText = `position:fixed;left:50%;top:40%;width:8px;height:14px;background:${cols[i % 4]};z-index:400;pointer-events:none`;
      document.body.appendChild(c);
      gsap.to(c, { x: (Math.random() - 0.5) * innerWidth, y: innerHeight * (0.3 + Math.random() * 0.6), rotation: Math.random() * 720, opacity: 0, duration: 1.6 + Math.random(), ease: 'power2.out', onComplete: () => c.remove() });
    }
  }, [done]);

  if (!open) return null;
  const close = () => gsap.to(root.current, { clipPath: 'circle(0% at 90% 8%)', duration: 0.7, ease: 'power3.inOut', onComplete: () => { lockScroll(false); onClose(); } });
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const setM = (i, v) => setF((s) => ({ ...s, members: s.members.map((m, j) => (j === i ? v : m)) }));

  const payload = () => ({ team: f.team.trim(), project: f.project.trim(), members: f.members.map((m) => m.trim()).filter(Boolean), phone: f.phone.trim(), email: f.email.trim(), fee: EVENT.fee, at: new Date().toISOString(), id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6) });
  const text = (p) => `${EVENT.prefix} ${EVENT.name} ${EVENT.level} — Registration\nTeam: ${p.team}\nProject: ${p.project}\nMembers: ${p.members.join(', ')}\nPhone: ${p.phone}\nEmail: ${p.email}\nFee: Rs ${EVENT.fee} per team`;

  const submit = async (e) => {
    e.preventDefault();
    const er = {};
    if (!f.team.trim()) er.team = 'Team name is required';
    if (!f.project.trim()) er.project = 'Project name is required';
    if (!f.members[0].trim()) er.m0 = 'Team leader name is required';
    if (!/^\d{10}$/.test(f.phone.replace(/\s/g, ''))) er.phone = 'Enter a 10-digit number';
    if (!/^\S+@\S+\.\S+$/.test(f.email)) er.email = 'Enter a valid email';
    setErr(er);
    if (Object.keys(er).length) return gsap.fromTo('.rg-form', { x: -8 }, { x: 0, duration: 0.5, ease: 'elastic.out(1,.3)' });
    const p = payload(); setBusy(true);
    try {
      if (EVENT.registerEndpoint) {
        const r = await fetch(EVENT.registerEndpoint, { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8' }, body: JSON.stringify(p) });
        const j = await r.json();
        if (!j.ok) throw new Error(j.error || 'failed');
        setDone({ p, how: 'sent' });
      }
      else if (EVENT.whatsapp) { window.open(`https://wa.me/${EVENT.whatsapp}?text=${encodeURIComponent(text(p))}`, '_blank'); setDone({ p, how: 'wa' }); }
      else setDone({ p, how: 'copy' });
    } catch { setDone({ p, how: 'fail' }); }
    setBusy(false);
  };

  const field = ({ label, k, type = 'text', ph, e }) => (
    <label key={k} className="rg-in fld"><span className="mono">{label}</span>
      <input type={type} value={f[k]} placeholder={ph} onChange={(x) => set(k, x.target.value)} />{e && <em>{e}</em>}</label>
  );

  return (
    <div className="reg" ref={root}>
      <button className="reg-x mono" onClick={close}>CLOSE ✕</button>
      <div className="reg-wrap">
        <div className="reg-side rg-in">
          <p className="kick mono">// TEAM REGISTRATION</p>
          <h2 className="d">{EVENT.prefix}<br />{EVENT.name}<br /><em>{EVENT.level}</em></h2>
          <div className="fee"><b className="d">₹{EVENT.fee}</b><span>Registration fee per team</span></div>
          <ul><li>Maximum {EVENT.teamSize} members per team</li><li>Prizes: {PRIZES.map((p) => '₹' + p.amount.toLocaleString('en-IN')).join(' · ')}</li><li>{EVENT.dates} · {EVENT.time}</li><li>{EVENT.venue}</li></ul>
          {EVENT.payNote && <p className="note">{EVENT.payNote}</p>}
        </div>
        {done ? (
          <div className="reg-form done">
            <svg viewBox="0 0 52 52" className="tick"><circle cx="26" cy="26" r="24" /><path d="M14 27l8 8 16-17" /></svg>
            <h3 className="d">{done.how === 'copy' ? 'Details ready' : done.how === 'fail' ? 'Not confirmed yet' : 'Registration received'}</h3>
            <p>{done.how === 'sent' && `Thanks, team ${done.p.team}! We have your details.`}{done.how === 'wa' && 'WhatsApp opened with your details. Press send to confirm.'}{done.how === 'copy' && 'Copy these details and send them to the organisers.'}{done.how === 'fail' && 'We could not confirm that your details reached us. Copy them and send to the organisers on Instagram, or try again.'}</p>
            <pre className="mono">{text(done.p)}</pre>
            {EVENT.whatsapp && <a className="btn" href={`https://wa.me/${EVENT.whatsapp}?text=${encodeURIComponent(text(done.p))}`} target="_blank" rel="noreferrer">Send on WhatsApp</a>}
            <button className="btn" onClick={() => navigator.clipboard && navigator.clipboard.writeText(text(done.p))}>Copy details</button>
            {done.how === 'fail' && <button className="ghost" onClick={() => setDone(null)}>Try again</button>}
            <button className="ghost" onClick={close}>Back to site</button>
          </div>
        ) : (
          <form className="reg-form rg-form" onSubmit={submit} noValidate>
            {field({ label: "TEAM NAME", k: "team", ph: "e.g. Code Pilots", e: err.team })}
            {field({ label: "PROJECT NAME", k: "project", ph: "What are you building?", e: err.project })}
            <p className="rg-in mono lab">TEAM MEMBERS (UP TO {EVENT.teamSize}) — MEMBER 1 IS THE TEAM LEADER</p>
            <div className="mem">{f.members.map((m, i) => (
              <label key={i} className="rg-in fld"><span className="mono">MEMBER {i + 1}{i === 0 ? ' *' : ''}</span>
                <input value={m} placeholder="Full name" onChange={(x) => setM(i, x.target.value)} />{i === 0 && err.m0 && <em>{err.m0}</em>}</label>))}</div>
            <div className="mem">{field({ label: "LEADER PHONE", k: "phone", type: "tel", ph: "10-digit number", e: err.phone })}{field({ label: "LEADER EMAIL", k: "email", type: "email", ph: "name@email.com", e: err.email })}</div>
            {err.form && <em>{err.form}</em>}
            <button className="btn rg-in" disabled={busy}>{busy ? 'Sending…' : `Register team · ₹${EVENT.fee}`}</button>
          </form>
        )}
      </div>
    </div>
  );
}
