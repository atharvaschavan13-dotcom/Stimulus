import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { EVENT, FLEET, FUN, PRIZES, FAQ } from '../data/event.js';
import EventModal from './EventModal.jsx';
import Art, { DroneIcon } from './Art.jsx';
gsap.registerPlugin(ScrollTrigger);

export function Marquee() {
  const word = ['Acharya', 'Stimulus', 'Level 2', '15–16 Oct 2026', '₹50,000 Prizes', 'ACCES', 'XR/VR', 'Drones', 'AI'];
  return <div className="mq"><div className="d">{Array(4).fill(word).flat().map((w, i) => <span key={i}>{w}</span>)}</div></div>;
}

export function Countdown() {
  const [d, setD] = useState(0);
  useEffect(() => { const T = new Date(EVENT.start), tick = () => setD(Math.max(0, T - new Date())); tick(); const iv = setInterval(tick, 1000); return () => clearInterval(iv); }, []);
  const f = (n) => String(n).padStart(2, '0');
  const parts = [['Days', Math.floor(d / 864e5)], ['Hours', Math.floor(d / 36e5) % 24], ['Mins', Math.floor(d / 6e4) % 60], ['Secs', Math.floor(d / 1e3) % 60]];
  return (
    <section id="about">
      <div className="kick mono scr">// 00 / COUNTDOWN</div>
      <h2 className="d rv">Takeoff in</h2>
      <p className="sub rv">{EVENT.dates} · {EVENT.time} IST</p>
      <div className="cd rv">{parts.map(([l, v]) => <div key={l}><b>{f(v)}</b><small>{l}</small></div>)}</div>
    </section>
  );
}

// Events hang from roaming drones: drag to swing, tap for details.
function Hanger({ e, i, onOpen }) {
  const ref = useRef(null), st = useRef({ down: false, x: 0, moved: false });
  const down = (ev) => { st.current = { down: true, x: ev.clientX, moved: false }; ev.currentTarget.setPointerCapture(ev.pointerId); gsap.killTweensOf(ref.current); ref.current.classList.add('drag'); gsap.set(ref.current, { transformOrigin: '50% 0', rotation: 0 }); };
  const move = (ev) => { if (!st.current.down) return; const dx = ev.clientX - st.current.x; if (Math.abs(dx) > 6) st.current.moved = true; gsap.set(ref.current, { rotation: gsap.utils.clamp(-28, 28, dx * 0.12) }); };
  const up = () => {
    if (!st.current.down) return; st.current.down = false;
    const was = st.current.moved;
    gsap.to(ref.current, { rotation: 0, duration: 1.8, ease: 'elastic.out(1,.22)', onComplete: () => { ref.current.classList.remove('drag'); gsap.set(ref.current, { clearProps: 'transform' }); } });
    if (!was) onOpen(i);
  };
  return (
    <div className="roam" style={{ '--i': i }}>
      <DroneIcon />
      <div className="swing" ref={ref} style={{ '--i': i }} onPointerDown={down} onPointerMove={move} onPointerUp={up} onPointerCancel={up}>
        <div className="ropes"><i /><i /></div>
        <div className="hcard">
          {e.photo ? <img className="hphoto" src={e.photo} alt={e.title} draggable="false" /> : <Art k={e.art} />}
          <span className="tag mono scr">{e.tag}</span><h3 className="d scr">{e.title}</h3><p>{e.text}</p>
          <span className="more2 mono">TAP FOR DETAILS ↗</span>
        </div>
      </div>
    </div>
  );
}

export function Fleet({ onRegister }) {
  const [sel, setSel] = useState(null);
  useEffect(() => {
    const tw = gsap.fromTo('.fly', { y: -520, opacity: 0, rotate: -8 }, { y: 0, opacity: 1, rotate: 0, stagger: 0.2, duration: 1.8, ease: 'power4.out', scrollTrigger: { trigger: '.fleet', start: 'top 85%' } });
    return () => { tw.scrollTrigger && tw.scrollTrigger.kill(); tw.kill(); };
  }, []);
  return (
    <section id="zonals">
      <div className="kick mono scr">// 01 / EVENTS</div>
      <h2 className="d rv">The <em>Fleet</em></h2>
      <p className="sub rv">Four zones, each delivered by its own drone. Drag a card to swing it, tap to open it.</p>
      <div className="fleet">{FLEET.map((e, i) => <div className="fly" key={e.id}><Hanger e={e} i={i} onOpen={setSel} /></div>)}</div>
      {sel !== null && <EventModal e={FLEET[sel]} onClose={() => setSel(null)} onNav={(d) => setSel((sel + d + FLEET.length) % FLEET.length)} onRegister={onRegister} />}
    </section>
  );
}

const MEDAL = { gold: ['#fff2a8', '#f5b800'], silver: ['#ffffff', '#9fb0c8'], bronze: ['#ffd0a0', '#c9783a'] };
export function Prizes({ onRegister }) {
  const root = useRef(null), total = PRIZES.reduce((a, p) => a + p.amount, 0), order = [1, 0, 2];
  const money = (n) => '₹' + Math.round(n).toLocaleString('en-IN');
  useEffect(() => {
    const ctx = gsap.context(() => {
      ScrollTrigger.create({ trigger: root.current, start: 'top 70%', once: true, onEnter: () => {
        gsap.fromTo('.pblock', { scaleY: 0 }, { scaleY: 1, transformOrigin: 'bottom', stagger: 0.18, duration: 1.2, ease: 'elastic.out(1,.6)' });
        gsap.fromTo('.pmedal', { y: -260, opacity: 0, rotate: -40 }, { y: 0, opacity: 1, rotate: 0, stagger: 0.18, delay: 0.5, duration: 1.2, ease: 'bounce.out' });
        root.current.querySelectorAll('[data-amt]').forEach((el) => { const o = { v: 0 }, to = +el.dataset.amt; gsap.to(o, { v: to, duration: 2.2, ease: 'power2.out', onUpdate: () => (el.textContent = money(o.v)) }); });
      } });
    }, root);
    return () => ctx.revert();
  }, []);
  const pop = (e) => {
    const r = e.currentTarget.getBoundingClientRect(), cols = ['#f5b800', '#00e5ff', '#ff3d9a', '#b04cff', '#fff'];
    for (let i = 0; i < 40; i++) { const c = document.createElement('i'); c.style.cssText = `position:fixed;left:${r.left + r.width / 2}px;top:${r.top}px;width:7px;height:12px;background:${cols[i % 5]};z-index:400;pointer-events:none`; document.body.appendChild(c); gsap.to(c, { x: (Math.random() - 0.5) * 360, y: -80 - Math.random() * 220, rotation: Math.random() * 540, opacity: 0, duration: 1.3, ease: 'power2.out', onComplete: () => c.remove() }); }
  };
  return (
    <section id="prizes" ref={root}>
      <div className="kick mono scr">// 02 / PRIZES</div>
      <h2 className="d rv">Win <em>Big</em></h2>
      <div className="prize-top rv">
        <div className="roam" style={{ '--i': 2 }}><DroneIcon /><div className="swing" style={{ '--i': 2 }}><div className="ropes"><i /><i /></div>
          <div className="pool"><small className="mono">TOTAL PRIZE POOL</small><b className="d" data-amt={total}>₹0</b></div></div></div>
      </div>
      <div className="podium">
        {order.map((idx) => { const p = PRIZES[idx], [c1, c2] = MEDAL[p.medal]; return (
          <div className={'pod pod' + idx} key={p.place} onClick={pop}>
            <svg className="pmedal" viewBox="0 0 80 100"><path d="M24 0l16 34 16-34" fill="none" stroke={c2} strokeWidth="9" /><circle cx="40" cy="62" r="30" fill={c1} stroke={c2} strokeWidth="5" /><circle cx="40" cy="62" r="22" fill="none" stroke={c2} strokeWidth="2" opacity=".6" /><text x="40" y="72" textAnchor="middle" fontSize="26" fontWeight="700" fill="#2a1d00" fontFamily="Oswald,sans-serif">{idx + 1}</text></svg>
            <div className="pamt d" data-amt={p.amount}>₹0</div><div className="plab mono">{p.label}</div>
            <div className="pblock" style={{ '--g': `linear-gradient(180deg,${c2},rgba(4,5,10,.2))`, height: [220, 160, 120][idx] }}><span className="d">{p.place}</span></div>
          </div>); })}
      </div>
      <p className="sub rv" style={{ textAlign: 'center', marginTop: 30 }}>Tap a podium to celebrate. <button className="ghost" onClick={onRegister}>Register to compete</button></p>
    </section>
  );
}

export function Faq() {
  const [o, setO] = useState(0);
  return (
    <section id="faq">
      <div className="kick mono scr">// 06 / QUESTIONS</div>
      <h2 className="d rv">Got <em>Questions?</em></h2>
      <div className="faq rv">{FAQ.map(([q, a], i) => (
        <div key={q} className={'fq' + (o === i ? ' open' : '')}><button onClick={() => setO(o === i ? -1 : i)}><span>{q}</span><i>+</i></button><div className="fa"><p>{a}</p></div></div>
      ))}</div>
    </section>
  );
}

export function Fun() {
  return (
    <section id="fun">
      <div className="kick mono scr">// 03 / FUN ZONE</div>
      <h2 className="d rv">Games, Stage &amp; <em>More</em></h2>
      <div className="funs">
        {FUN.map((x, i) => <div className="fcard rv" key={i}><Art k={x.art} /><h3 className="d scr">{x.title}</h3><p>{x.text}</p></div>)}
      </div>
    </section>
  );
}

export function Gallery() {
  if (!EVENT.gallery.length) return null;
  const tilt = (e) => { const c = e.currentTarget, r = c.getBoundingClientRect(); c.style.transform = `perspective(800px) rotateY(${((e.clientX - r.left) / r.width - 0.5) * 12}deg) rotateX(${-((e.clientY - r.top) / r.height - 0.5) * 12}deg) scale(1.02)`; };
  return (
    <section id="gallery">
      <div className="kick mono scr">// 04 / GALLERY</div>
      <h2 className="d rv">Mission <em>Visuals</em></h2>
      <div className="gal rv">{EVENT.gallery.map((g) => (
        <figure key={g.src} onMouseMove={tilt} onMouseLeave={(e) => (e.currentTarget.style.transform = '')}><img src={g.src} alt={g.cap} loading="lazy" /><figcaption className="mono">{g.cap}</figcaption></figure>
      ))}</div>
    </section>
  );
}

export function Venue() {
  const items = [['Dates', EVENT.dates], ['Time', EVENT.time], ['Venue', EVENT.venue], ['Registration', `₹${EVENT.fee} per team · up to ${EVENT.teamSize} members`], ['Presented by', `${EVENT.organiser} × ${EVENT.partner}`]];
  return (
    <section id="when">
      <div className="kick mono scr">// 05 / VENUE</div>
      <h2 className="d rv">Where &amp; <em>When</em></h2>
      <div className="info rv">{items.map(([k, v]) => <div key={k}><small>{k}</small><p>{v}</p></div>)}</div>
    </section>
  );
}

export function Footer({ onRegister }) {
  return (
    <footer id="contact">
      <img className="flogo" src="/images/logo.png" alt="Stimulus" />
      <p className="d fl">{EVENT.prefix} {EVENT.name} {EVENT.level}</p>
      <button className="btn" onClick={onRegister}>Register your team · ₹{EVENT.fee}</button>
      <p style={{ margin: '28px 0 8px' }}>More information can be seen at</p>
      {EVENT.instagram.map((i) => <a key={i.url} href={i.url} target="_blank" rel="noreferrer">{i.label}</a>)}
      <p className="made mono">DESIGNED &amp; BUILT BY TEAM STIMULUS</p>
    </footer>
  );
}
